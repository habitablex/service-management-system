Service Management System (SMS)
By Habitable Solution
Website: habitablesolution.com/download
Version: 2.1

How to open:
Double-click HS_Service_Management_System_v2.exe

Theme:
Go to Settings > Theme Option and choose Light, Dark, Blue, Green, or Gold.
The selected theme will save automatically.

Important:
Do not delete the data folder.
Your service records and theme settings are stored inside the data folder.
Use the Backup tab every day to save a backup copy.

Support:
Contact Habitable Solution for installation, customization, and training.
