HS Service Management System v2.1
Commercial Offline Desktop Edition
By Habitable Solution
Website: habitablesolution.com/download

WHAT THIS PACKAGE IS
This is a VS Code editable Python + SQLite offline service management system.
It is designed for computer/laptop/UPS/printer/GPU/networking/CCTV service businesses.

NEW IN v2.1
- Top bar title changed to: Service Management System (SMS)
- Theme option added in Settings
- Themes included: Light, Dark, Blue, Green, Gold
- Theme choice saves automatically for next launch
- Bottom branding/footer added
- Database and config now save beside the EXE/source folder for safer client delivery

IMPORTANT
The real Windows .exe must be built on a Windows computer. This package includes a ready build script.
After build, your final file will be:
dist\HS_Service_Management_System_v2.exe

HOW TO RUN SOURCE IN VS CODE
1. Install Python 3.11+ from python.org.
2. Open this folder in VS Code.
3. Open Terminal.
4. Run:
   python HS_Service_Management_System_v2.py

HOW TO BUILD WINDOWS EXE
1. Open this folder on a Windows PC.
2. Double-click build_windows_exe.bat
   or run it from Command Prompt.
3. Wait until build completes.
4. Find the EXE inside dist folder:
   dist\HS_Service_Management_System_v2.exe

DATABASE
The app stores data in:
data\hs_sms_v2.db

THEME CONFIG
The app stores theme settings in:
data\hs_sms_config.json

BACKUP RULE
For client use, tell them to backup daily from the Backup tab.
Never delete the data folder.

MODULES INCLUDED
- Dashboard
- Customer Management
- Device Management
- Service Jobs
- Status Tracking
- Priority
- Problem Description
- Engineer Notes
- Work Logs
- Parts Used
- Invoice / Money Receipt Preview
- Warranty Tracking
- Reports
- Theme Options
- Service Types Settings
- Device Category Settings
- SQLite Backup / Restore
- JSON Export
- About / Branding

CLIENT DELIVERY SUGGESTION
After building the EXE, deliver these files/folders:
1. HS_Service_Management_System_v2.exe
2. data folder
3. backups folder
4. README_CLIENT.txt

Do not deliver the Python source file to normal clients unless they paid for source code.
