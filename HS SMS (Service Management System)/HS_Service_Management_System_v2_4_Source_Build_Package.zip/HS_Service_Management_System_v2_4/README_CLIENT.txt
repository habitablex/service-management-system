Service Management System (SMS)
By Habitable Solution
Website: habitablesolution.com/download
Version: 2.4

How to open:
Double-click HS_Service_Management_System_v2_4.exe

Theme:
Go to Settings > Theme Option and choose Light, Dark, Blue, Green, or Gold.
The selected theme will save automatically.

Invoice Print:
Go to Invoice / Warranty, select a job, then click Open. The invoice will open in your browser. Click Print / Save PDF or press Ctrl+P to print.

Important:
Do not delete the data folder.
Your service records and theme settings are stored inside the data folder. Browser invoice files are stored inside the invoices folder.
Use the Backup tab every day to save a backup copy. Backups are saved by default in Documents > Habitable Solution > HS Service Management System > backups. You can click Open Backup Folder from the Backup tab to open the backup location directly. The software also shows the last backup date/time and last restore date/time.

Support:
Contact Habitable Solution for installation, customization, and training.


Version 2.4 Added:
- Custom icon support via assets/hs_sms_icon.ico and assets/hs_sms_icon.png.
- Default Theme option that follows the computer theme where supported.
- More themes: Dark Pro, Midnight Dark, Graphite Dark, Glass, iMac, Ubuntu.
- Open Assets Folder option in Settings for icon replacement.

To add your own icon before building EXE:
1. Open the assets folder.
2. Replace hs_sms_icon.ico with your own .ico file.
3. Optional: replace hs_sms_icon.png for the app/window icon preview.
4. Run build_windows_exe.bat again.
