HS Service Management System v3.0
Commercial Offline Desktop Edition
Developed by Habitable Solution
Website: https://habitablesolution.com
Download: https://habitablesolution.com/download
Support Email: info@habitablesolution.com

HOW TO USE
1. Double-click the EXE file to open the software.
2. Add customers, devices, service jobs, work logs, parts, invoices, and warranty records.
3. Use the Backup tab regularly to protect your data.
4. When closing the app, choose whether to take a backup before closing.

DATA SAFETY
The software stores data locally on this computer.
Do not delete the data folder beside the app.
Backups are saved by default inside your Documents folder:
Documents > Habitable Solution > HS Service Management System > backups

SUPPORT
Website: https://habitablesolution.com
Download Page: https://habitablesolution.com/download
Email: info@habitablesolution.com
