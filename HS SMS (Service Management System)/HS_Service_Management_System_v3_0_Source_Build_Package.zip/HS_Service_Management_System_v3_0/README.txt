HS Service Management System v3.0
Commercial Offline Desktop Edition
By Habitable Solution
Website: https://habitablesolution.com/download
Email: info@habitablesolution.com

WHAT THIS PACKAGE IS
This is a VS Code editable Python + SQLite offline service management system.
It is designed for computer/laptop/UPS/printer/GPU/networking/CCTV service businesses.

NEW IN v3.0
- Professional About section.
- Active branding links in the About section.
- Active website, download page, and support email links.
- Clickable footer branding links.
- About buttons: Open Website, Open Download Page, Email Support, Open App Folder, Open Backup Folder.

INCLUDED FROM PREVIOUS VERSIONS
- Top bar title: Service Management System (SMS)
- Theme option in Settings
- Default Theme follows Windows Light/Dark app mode
- Themes included: Default Theme Windows sync, Light, Dark, Dark Pro, Midnight Dark, Graphite Dark, Glass, iMac, Ubuntu, Blue, Green, Gold
- Bottom branding/footer
- Custom icon support via assets/hs_sms_icon.ico and assets/hs_sms_icon.png
- Invoice Open button that opens a clean browser invoice with Print / Save PDF
- Backup section with last backup date/time and last restore date/time
- Open Backup Folder button
- Default backup folder inside Documents > Habitable Solution > HS Service Management System > backups
- Close backup choice: Yes = Backup & Close, No = Close Without Backup, Cancel = Stay in App
- Startup restore prompt with Browse Backup File option

IMPORTANT
The real Windows .exe must be built on a Windows computer. This package includes a ready build script.
After build, your final file will be:
dist\HS_Service_Management_System_v3_0.exe

HOW TO RUN SOURCE IN VS CODE
1. Install Python 3.11+ from python.org.
2. Open this folder in VS Code.
3. Open Terminal.
4. Run:
   python HS_Service_Management_System_v2.py

HOW TO BUILD WINDOWS EXE
1. Open this folder on a Windows PC.
2. Double-click build_windows_exe.bat or run it from Command Prompt.
3. Wait until build completes.
4. Find the EXE inside dist folder:
   dist\HS_Service_Management_System_v3_0.exe

DATABASE
The app stores data in:
data\hs_sms_v2.db

CONFIG
The app stores theme and backup/restore status in:
data\hs_sms_config.json

BACKUP RULE
Backups are saved by default in:
Documents > Habitable Solution > HS Service Management System > backups

CLIENT DELIVERY
Give the client the final EXE and README_CLIENT.txt. Do not send the Python source code unless source code is included in the sale.
