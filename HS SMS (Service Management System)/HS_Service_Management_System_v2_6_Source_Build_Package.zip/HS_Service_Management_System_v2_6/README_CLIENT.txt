Service Management System (SMS)
By Habitable Solution
Website: habitablesolution.com/download
Version: 2.6

How to open:
Double-click HS_Service_Management_System_v2_6.exe

Theme:
Go to Settings > Theme Option and choose your preferred theme.
The selected theme will save automatically.

Invoice Print:
Go to Invoice / Warranty, select a job, then click Open.
The invoice will open in your browser.
Click Print / Save PDF or press Ctrl+P to print.

Backup:
Backups are saved by default in:
Documents > Habitable Solution > HS Service Management System > backups

The Backup tab shows:
- Last backup date/time
- Last restore date/time
- Last backup file path
- Last restore file path
- Open Backup Folder button

Auto Backup:
The software creates an automatic backup when the app is closed.
A success message will appear before closing.

Important:
Do not delete the data folder if it exists beside the app.
Your service records and settings are stored there.
Generated browser invoice files are stored inside the invoices folder.

Support:
Contact Habitable Solution for installation, customization, and training.
