Service Management System (SMS)
By Habitable Solution
Website: habitablesolution.com/download
Version: 2.3

How to open:
Double-click HS_Service_Management_System_v2_3.exe

Theme:
Go to Settings > Theme Option and choose Light, Dark, Blue, Green, or Gold.
The selected theme will save automatically.

Invoice Print:
Go to Invoice / Warranty, select a job, then click Open. The invoice will open in your browser. Click Print / Save PDF or press Ctrl+P to print.

Important:
Do not delete the data folder.
Your service records and theme settings are stored inside the data folder. Browser invoice files are stored inside the invoices folder.
Use the Backup tab every day to save a backup copy. Backups are saved by default in Documents > Habitable Solution > HS Service Management System > backups. You can click Open Backup Folder from the Backup tab to open the backup location directly. The software also shows the last backup date/time and last restore date/time.

Support:
Contact Habitable Solution for installation, customization, and training.
