Service Management System (SMS)
By Habitable Solution
Website: habitablesolution.com/download
Version: 2.9

How to open:
Double-click HS_Service_Management_System_v2_9.exe

Theme:
Go to Settings > Theme Option and choose your preferred theme.
The selected theme will save automatically.
Default Theme follows the Windows/computer Light-Dark theme.
Use Sync Windows Theme Now if you want to force the app to match Windows immediately.

Invoice Print:
Go to Invoice / Warranty, select a job, then click Open.
The invoice will open in your browser.
Click Print / Save PDF or press Ctrl+P to print.

Backup:
Backups are saved by default in:
Documents > Habitable Solution > HS Service Management System > backups

The Backup tab shows:
- Last backup date/time
- Last restore date/time
- Last backup file path
- Last restore file path
- Open Backup Folder button

Auto Backup:
When closing the software, it can ask whether you want to take a backup.
Choose Yes to Backup & Close, No to Close Without Backup, or Cancel to stay in the app.
You can turn this close-backup question on/off from the Backup section.

Startup Restore:
When the app opens, it can ask whether you want to restore a backup.
You can click Restore Latest Backup, Browse Backup File, or Continue Without Restore.
Use Browse Backup File when the backup is on a pen drive, another folder, or cloud-synced folder.
Restore only if you want to replace the current data with the selected backup file.
You can turn this option on/off from the Backup section.

Important:
Do not delete the data folder if it exists beside the app.
Your service records and settings are stored there.
Generated browser invoice files are stored inside the invoices folder.

Support:
Contact Habitable Solution for installation, customization, and training.


v2.9 Update:
- App close now asks whether to take a backup.
- Options: Yes = Backup & Close, No = Close Without Backup, Cancel = Stay in App.
- Backup tab includes a Close Backup Option toggle.
- Existing invoice, theme, startup restore, and icon features are unchanged.
