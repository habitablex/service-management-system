HS Service Management System v2
By Habitable Solution
Website: habitablesolution.com/download

How to open:
Double-click HS_Service_Management_System_v2.exe

Important:
Do not delete the data folder.
Your service records are stored inside the data folder.
Use the Backup tab every day to save a backup copy.

Support:
Contact Habitable Solution for installation, customization, and training.
