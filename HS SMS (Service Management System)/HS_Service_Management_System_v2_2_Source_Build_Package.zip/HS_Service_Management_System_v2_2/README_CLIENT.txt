Service Management System (SMS)
By Habitable Solution
Website: habitablesolution.com/download
Version: 2.2

How to open:
Double-click HS_Service_Management_System_v2_2.exe

Theme:
Go to Settings > Theme Option and choose Light, Dark, Blue, Green, or Gold.
The selected theme will save automatically.

Invoice Print:
Go to Invoice / Warranty, select a job, then click Open. The invoice will open in your browser. Click Print / Save PDF or press Ctrl+P to print.

Important:
Do not delete the data folder.
Your service records and theme settings are stored inside the data folder. Browser invoice files are stored inside the invoices folder.
Use the Backup tab every day to save a backup copy.

Support:
Contact Habitable Solution for installation, customization, and training.
