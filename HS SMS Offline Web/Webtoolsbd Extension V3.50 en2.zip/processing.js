


var inputUrl = window.location.href;

var parts = inputUrl.split("?");
var modifiedUrl = parts[0]; // This will contain the URL without query parameters

var resultUrl = modifiedUrl;

if (resultUrl === 'https://www.semrush.com/multilogin/') {
    window.location.href = 'https://app.webtoolsbd.com/page/semrush';
};








//   $(".flex.flex-col.pt-2").css("display", "none");
    
function rmv(){
    //chatGPTx
    var chatGPTx = document.querySelector('.flex.gap-2.pr-1');
    if (chatGPTx) {
    chatGPTx.style.display = 'none';
    }
    var chatGPTxr = document.querySelector('span.flex.w-full.flex-row.flex-wrap-reverse.justify-between');
    if (chatGPTxr) {
    chatGPTxr.style.display = 'none';
    }
     var chatGPTxMM = document.querySelector('button.btn.relative.btn-primary.m-auto');
    if (chatGPTxMM) {
    chatGPTxMM.style.display = 'none';
    } 
    var chatGPTxRR = document.querySelector('button.btn.relative.btn-primary.shrink-0');
    if (chatGPTxRR) {
    chatGPTxRR.style.display = 'none';
    }
    
    
     //Uberx
    var Ubersx = document.querySelector('.sc-bOKIsT.jqjzeN');
    if (Ubersx) {Ubersx.style.display = 'none';}
    
    var Ubersxs = document.querySelector('.sc-cocQYQ.kRRBij');
    if (Ubersxs) {Ubersxs.style.display = 'none';}


    //Moz Pr
    var Mozx = document.querySelector('li.mgn-profile.mgn-selectable');
    if (Mozx) {Mozx.style.display = 'none';}
    
    
    //seosite
    var seositex = document.querySelector('.ant-btn.user-dropdown-button.ant-dropdown-trigger');
    if (seositex) {seositex.style.display = 'none';}
    var seositexs = document.querySelector('.package-container');
    if (seositexs) {seositexs.style.display = 'none';}
    
    //Smimiler
    var Smimilerx = document.querySelector('.SecondaryItemsWrapper-iPlsGa.cQFwXS');
    if (Smimilerx) {Smimilerx.style.display = 'none';}
    
    //Wordtune
    var wordtnx = document.querySelector('footer.bg-paper-system.flex.w-full.flex-col.justify-center.gap-2');
    if (wordtnx) {wordtnx.style.display = 'none';}
      
      
      //rf
    var rf = document.querySelector('.BenefitPlus_priceContainer__7qPC8');
    if (rf) {rf.style.display = 'none';}
    
    var rfx = document.querySelector('.SearchFilterCategoryDropdown__wrapper');
    if (rfx) {rfx.style.display = 'none';} 
    
    var rfy = document.querySelector('.SearchCollectionSection__button--left');
    if (rfy) {rfy.style.display = 'none';}
    
    
       //Zoominfo
    var zoominfox = document.querySelector('button.zic-topbar-user-menu-button');
    if (zoominfox) {zoominfox.style.display = 'none';}
    var zoominfoy = document.querySelector('button#btn-pricing');
    if (zoominfoy) {zoominfoy.style.display = 'none';}
    
    
       //Zoominfo
    var semrs = document.querySelector('.srf-navbar__right');
    if (semrs) {semrs.style.display = 'none';}
    
    
           //You.com
    var you = document.querySelector('.wflmpe0');
    if (you) {you.style.display = 'none';} 
    
    var yous = document.querySelector('.vcm2u71');
    if (yous) {yous.style.display = 'none';}   
    
    var Ubers = document.querySelector('.hwbaHu');
    if (Ubers) {Ubers.style.display = 'none';}
       
    
    var Storybase = document.querySelector('#sidebar-profile');
    if (Storybase) {Storybase.style.display = 'none';}
      
    
    //  console.log('i am Webtoolsbd');

}       


setInterval(rmv, 500);
