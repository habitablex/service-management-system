// console.log("working me");

function getDomainFromUrl(url) {
    var match = url.match(/^(?:https?:\/\/)?(?:www\.)?([^\/]+)/);
    return match ? match[1] : null;
  }
  
  // Example usage:
  var url = window.location.href;
  var domain = getDomainFromUrl(url);
//   console.log("Domain:", domain);
  chrome.runtime.sendMessage({ action: "cookiesFind", doms: domain});


 

  setTimeout(function () {
    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.doms === "semrush.com") {

    
            chrome.cookies.getAll({ domain: "semrush.com" }, function(cookies) {

                var cookiesToStore = [];

                for (var i = 0; i < cookies.length; i++) {
                  var cookie = cookies[i];

                  cookiesToStore.push({
                    url: "https://" + cookie.domain + cookie.path,
                    name: cookie.name,
                    storeId: cookie.storeId
                  });

             
                // Cookies remove
              
                  chrome.cookies.remove({ url: "https://" + cookie.domain + cookie.path, name: cookie.name, storeId: cookie.storeId });
                
                
                // for (var i = 0; i < cookiesToStore.length; i++) {
                //     var cookie = cookiesToStore[i];
                //     chrome.cookies.set({
                //         url: "https://" + cookie.domain + cookie.path,
                //         name: cookie.name,
                //         value: cookie.value,
                //         expirationDate: cookie.expirationDate,
                //         storeId: cookie.storeId
                //       });
                
                // }

                

              }
                

                // set cookies

                console.log(cookiesToStore);
                

              
              });


        }else{
            alert("I am Not"); 
        }
      });

  }, 2000);


 

// console.log(window.location.href);





// code bakup
// Proxy Update Section
function getDomainFromUrl(url) {
  var match = url.match(/^(?:https?:\/\/)?(?:www\.)?([^\/]+)/);
  return match ? match[1] : null;
}

var url = window.location.href;
var domain = getDomainFromUrl(url);


chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === 'complete' && tab.active) {
    if (getDomainFromUrl(tab.url) == "whatismyip.net") {
      enableProxy();
      console.log("i am  working");
    } else {
      disableProxy();
      console.log("i am not working");
    }
  }
});


function enableProxy() {

 
  const proxyConfig = {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http",
        host: "45.94.47.66",
        port: 8110
      },
      bypassList: ["localhost"]
    }
  };



  chrome.proxy.settings.set({ value: proxyConfig, scope: 'regular' }, function() {
    console.log("Proxy enabled");
  });


  
  chrome.webRequest.onAuthRequired.addListener(
    function(details, callbackFn) {
      return {authCredentials: {username: "ccdnimhn", password: "e4fakicobim6"}};
    },
    {urls: ["<all_urls>"]},
    ["blocking"]
  );



}

function disableProxy() {
  chrome.proxy.settings.clear({scope: 'regular'}, function() {
    console.log('Proxy settings have been reset to default');
  })
}