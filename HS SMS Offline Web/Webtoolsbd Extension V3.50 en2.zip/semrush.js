$(".srf-navbar__right").remove();

// var url = window.location.href;
// chrome.runtime.sendMessage({ action: "SemLoad",url:url});

