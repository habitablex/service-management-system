HS Service Management System - Offline Python App

How to run:
1. Install Python 3.10 or newer.
2. Open this folder in VS Code.
3. Open Terminal in VS Code.
4. Run: python hs_sms_desktop.py

Database:
- The app creates hs_sms.db in the same folder.
- Do not delete hs_sms.db unless you want to remove all data.
- Use Backup tab regularly.

No internet, hosting, WordPress, MySQL, or extra package needed.
