HS Service Management System - Offline MVP
=========================================

How to use:
1. Extract the ZIP file.
2. Open index.html in Google Chrome, Microsoft Edge, or Firefox.
3. The app works offline. No internet, hosting, database, or WordPress login is required.
4. Data is saved inside the same browser using localStorage.

Important:
- Use Export Backup every day. It will download a JSON backup file.
- Do not clear browser data unless you already exported a backup.
- For office/team use, keep one dedicated computer/browser for this offline version.
- Later this can be converted into a WordPress plugin, Laravel app, or Android/Desktop app.

Included Modules:
- Dashboard
- Customers
- Devices
- Service Jobs
- Job Status
- Work Logs
- Parts Used
- Invoice / Money Receipt print
- Warranty tracking
- Search
- Reports
- Settings
- Backup import/export

Recommended next version:
- Login system
- Real database: SQLite/MySQL
- Barcode/QR code
- WhatsApp/SMS
- Customer portal
- Inventory and stock management
- Desktop installer
