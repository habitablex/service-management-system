const HS = {
  key: 'hs_sms_offline_v1',
  statuses: ['Received', 'Inspection', 'Waiting Parts', 'Under Repair', 'Testing', 'Ready', 'Delivered', 'Cancelled'],
  defaultServiceTypes: ['Computer Service','Laptop Service','Desktop Service','Gaming PC','MacBook Service','Printer Service','UPS Service','GPU Service','Motherboard Repair','BIOS Programming','Chip Level Repair','Data Recovery','SSD Upgrade','RAM Upgrade','Windows Install','Virus Removal','Networking','CCTV','AMC Support','On-site Service','Remote Support','Custom Service'],
  defaultCategories: ['Laptop','Desktop','All-in-One','Server','UPS','Printer','Monitor','GPU','Motherboard','SSD','HDD','Router','Switch','CCTV DVR','MacBook','iMac','Custom Device'],
  data: null
};

function uid(prefix='id') { return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`; }
function todayISO() { return new Date().toISOString().slice(0,10); }
function formatDate(d) { if(!d) return '-'; return new Date(d + 'T00:00:00').toLocaleDateString('en-GB'); }
function money(n) { return `৳${Number(n || 0).toLocaleString('en-BD')}`; }
function esc(str='') { return String(str).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

function defaultData() {
  return {
    customers: [],
    devices: [],
    jobs: [],
    settings: {
      serviceTypes: [...HS.defaultServiceTypes],
      categories: [...HS.defaultCategories]
    }
  };
}
function loadData() {
  const raw = localStorage.getItem(HS.key);
  HS.data = raw ? JSON.parse(raw) : defaultData();
  HS.data.settings ||= { serviceTypes: [...HS.defaultServiceTypes], categories: [...HS.defaultCategories] };
  HS.data.settings.serviceTypes ||= [...HS.defaultServiceTypes];
  HS.data.settings.categories ||= [...HS.defaultCategories];
}
function saveData() { localStorage.setItem(HS.key, JSON.stringify(HS.data)); renderAll(); }

function el(id) { return document.getElementById(id); }
function currentSearch() { return el('globalSearch').value.trim().toLowerCase(); }

function matchesSearch(row, q) {
  if (!q) return true;
  return JSON.stringify(row).toLowerCase().includes(q);
}
function customerName(id) { return HS.data.customers.find(c => c.id === id)?.name || 'Unknown'; }
function customerMobile(id) { return HS.data.customers.find(c => c.id === id)?.mobile || ''; }
function deviceLabel(id) {
  const d = HS.data.devices.find(x => x.id === id);
  return d ? `${d.category || ''} ${d.brand || ''} ${d.model || ''} ${d.serial ? '('+d.serial+')' : ''}`.trim() : 'Unknown';
}

function generateJobNumber() {
  const d = new Date();
  const yy = String(d.getFullYear()).slice(2);
  const mm = String(d.getMonth()+1).padStart(2,'0');
  const count = HS.data.jobs.filter(j => j.jobNumber?.startsWith(`HS${yy}${mm}`)).length + 1;
  return `HS${yy}${mm}${String(count).padStart(4,'0')}`;
}

function setView(viewId) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active-view'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.view === viewId));
  el(viewId).classList.add('active-view');
  const titles = { dashboard: 'Dashboard', customers: 'Customers', devices: 'Devices', jobs: 'Service Jobs', reports: 'Reports', settings: 'Settings' };
  el('viewTitle').textContent = titles[viewId] || 'HS-SMS';
}

function renderAll() {
  renderSelects();
  renderDashboard();
  renderCustomers();
  renderDevices();
  renderJobs();
  renderReports();
  renderSettings();
}

function renderSelects() {
  const customerOptions = HS.data.customers.map(c => `<option value="${c.id}">${esc(c.name)} - ${esc(c.mobile)}</option>`).join('');
  ['deviceCustomer','jobCustomer'].forEach(id => { if(el(id)) el(id).innerHTML = `<option value="">Select customer</option>${customerOptions}`; });
  const categoryOptions = HS.data.settings.categories.map(c => `<option>${esc(c)}</option>`).join('');
  el('deviceCategory').innerHTML = `<option value="">Select category</option>${categoryOptions}`;
  const serviceOptions = HS.data.settings.serviceTypes.map(s => `<option>${esc(s)}</option>`).join('');
  el('jobServiceType').innerHTML = `<option value="">Select service</option>${serviceOptions}`;
  el('jobStatus').innerHTML = HS.statuses.map(s => `<option>${esc(s)}</option>`).join('');
  renderJobDeviceOptions();
}

function renderJobDeviceOptions(customerId = el('jobCustomer')?.value) {
  const devices = customerId ? HS.data.devices.filter(d => d.customerId === customerId) : HS.data.devices;
  el('jobDevice').innerHTML = `<option value="">Select device</option>` + devices.map(d => `<option value="${d.id}">${esc(deviceLabel(d.id))}</option>`).join('');
}

function renderDashboard() {
  const q = currentSearch();
  const today = todayISO();
  const jobs = HS.data.jobs;
  el('todayReceived').textContent = jobs.filter(j => j.createdAt === today).length;
  el('pendingJobs').textContent = jobs.filter(j => !['Delivered','Cancelled'].includes(j.status)).length;
  el('readyJobs').textContent = jobs.filter(j => j.status === 'Ready').length;
  const due = jobs.reduce((sum,j) => sum + Math.max(0, Number(j.estimate||0)-Number(j.paid||0)),0);
  el('dueAmount').textContent = money(due);
  const rows = jobs.filter(j => matchesSearch(enrichJob(j), q)).slice().sort((a,b) => b.createdAt.localeCompare(a.createdAt)).slice(0,8);
  el('recentJobs').innerHTML = jobsTable(rows);
}

function enrichJob(j) {
  return { ...j, customer: customerName(j.customerId), mobile: customerMobile(j.customerId), device: deviceLabel(j.deviceId) };
}

function jobsTable(rows) {
  if (!rows.length) return emptyHtml();
  return `<table><thead><tr><th>Job</th><th>Customer</th><th>Device</th><th>Service</th><th>Status</th><th>Due</th><th>Actions</th></tr></thead><tbody>${rows.map(j => `<tr>
    <td><strong>${esc(j.jobNumber)}</strong><br><small>${formatDate(j.createdAt)}</small></td>
    <td>${esc(customerName(j.customerId))}<br><small>${esc(customerMobile(j.customerId))}</small></td>
    <td>${esc(deviceLabel(j.deviceId))}</td>
    <td>${esc(j.serviceType)}</td>
    <td><span class="badge ${esc(j.status.split(' ')[0])}">${esc(j.status)}</span></td>
    <td>${money(Math.max(0, Number(j.estimate||0)-Number(j.paid||0)))}</td>
    <td><button class="mini-btn" onclick="openJobDetails('${j.id}')">View</button><button class="mini-btn" onclick="editJob('${j.id}')">Edit</button><button class="mini-btn danger" onclick="deleteJob('${j.id}')">Delete</button></td>
  </tr>`).join('')}</tbody></table>`;
}

function emptyHtml() { return el('emptyTemplate').innerHTML; }

function renderCustomers() {
  const q = currentSearch();
  const rows = HS.data.customers.filter(c => matchesSearch(c, q));
  if (!rows.length) { el('customerList').innerHTML = emptyHtml(); return; }
  el('customerList').innerHTML = `<table><thead><tr><th>Customer</th><th>Contact</th><th>Company</th><th>History</th><th>Actions</th></tr></thead><tbody>${rows.map(c => `<tr>
    <td><strong>${esc(c.name)}</strong><br><small>${esc(c.address || '')}</small></td>
    <td>${esc(c.mobile)}<br><small>${esc(c.email || '')}</small></td>
    <td>${esc(c.company || '-')}</td>
    <td>${HS.data.devices.filter(d=>d.customerId===c.id).length} devices<br>${HS.data.jobs.filter(j=>j.customerId===c.id).length} jobs</td>
    <td><button class="mini-btn" onclick="editCustomer('${c.id}')">Edit</button><button class="mini-btn danger" onclick="deleteCustomer('${c.id}')">Delete</button></td>
  </tr>`).join('')}</tbody></table>`;
}

function renderDevices() {
  const q = currentSearch();
  const rows = HS.data.devices.filter(d => matchesSearch({ ...d, customer: customerName(d.customerId) }, q));
  if (!rows.length) { el('deviceList').innerHTML = emptyHtml(); return; }
  el('deviceList').innerHTML = `<table><thead><tr><th>Device</th><th>Customer</th><th>Specs</th><th>Serial</th><th>Actions</th></tr></thead><tbody>${rows.map(d => `<tr>
    <td><strong>${esc(d.category)}</strong><br>${esc(d.brand || '')} ${esc(d.model || '')}</td>
    <td>${esc(customerName(d.customerId))}<br><small>${esc(customerMobile(d.customerId))}</small></td>
    <td>CPU: ${esc(d.processor || '-')}<br>RAM: ${esc(d.ram || '-')} / SSD: ${esc(d.ssd || '-')}</td>
    <td>${esc(d.serial || '-')}<br><small>${esc(d.asset || '')}</small></td>
    <td><button class="mini-btn" onclick="editDevice('${d.id}')">Edit</button><button class="mini-btn danger" onclick="deleteDevice('${d.id}')">Delete</button></td>
  </tr>`).join('')}</tbody></table>`;
}

function renderJobs() {
  const q = currentSearch();
  const rows = HS.data.jobs.filter(j => matchesSearch(enrichJob(j), q)).slice().sort((a,b) => (b.createdAt+b.jobNumber).localeCompare(a.createdAt+a.jobNumber));
  el('jobList').innerHTML = jobsTable(rows);
}

function renderReports() {
  const jobs = HS.data.jobs;
  el('reportCustomers').textContent = HS.data.customers.length;
  el('reportDevices').textContent = HS.data.devices.length;
  el('reportIncome').textContent = money(jobs.reduce((s,j)=>s+Number(j.paid||0),0));
  const soon = jobs.filter(j => warrantyEnd(j) && daysBetween(todayISO(), warrantyEnd(j)) <= 15 && daysBetween(todayISO(), warrantyEnd(j)) >= 0).length;
  el('reportWarranty').textContent = soon;
  el('topServices').innerHTML = listCounts(jobs.map(j=>j.serviceType));
  el('statusSummary').innerHTML = listCounts(jobs.map(j=>j.status));
}

function listCounts(items) {
  const counts = items.reduce((m,x)=>{ if(x) m[x]=(m[x]||0)+1; return m; },{});
  const rows = Object.entries(counts).sort((a,b)=>b[1]-a[1]);
  if (!rows.length) return emptyHtml();
  return `<table><thead><tr><th>Name</th><th>Total</th></tr></thead><tbody>${rows.map(([k,v])=>`<tr><td>${esc(k)}</td><td>${v}</td></tr>`).join('')}</tbody></table>`;
}

function renderSettings() {
  el('serviceTypeList').innerHTML = HS.data.settings.serviceTypes.map(s => `<span class="chip">${esc(s)} <button onclick="removeSetting('serviceTypes','${esc(s)}')">×</button></span>`).join('');
  el('categoryList').innerHTML = HS.data.settings.categories.map(s => `<span class="chip">${esc(s)} <button onclick="removeSetting('categories','${esc(s)}')">×</button></span>`).join('');
}

function daysBetween(a,b) { return Math.ceil((new Date(b+'T00:00:00') - new Date(a+'T00:00:00')) / 86400000); }
function addDays(date, days) { const d = new Date(date+'T00:00:00'); d.setDate(d.getDate()+Number(days||0)); return d.toISOString().slice(0,10); }
function warrantyEnd(job) { return job.deliveryDate ? addDays(job.deliveryDate, job.warrantyDays || 0) : ''; }

function collectCustomer() {
  return {
    id: el('customerId').value || uid('cus'),
    name: el('customerName').value.trim(), mobile: el('customerMobile').value.trim(), whatsapp: el('customerWhatsapp').value.trim(), email: el('customerEmail').value.trim(),
    company: el('customerCompany').value.trim(), address: el('customerAddress').value.trim(), notes: el('customerNotes').value.trim(), createdAt: todayISO()
  };
}
function editCustomer(id) {
  const c = HS.data.customers.find(x=>x.id===id); if(!c) return;
  el('customerId').value=c.id; el('customerName').value=c.name; el('customerMobile').value=c.mobile; el('customerWhatsapp').value=c.whatsapp||''; el('customerEmail').value=c.email||''; el('customerCompany').value=c.company||''; el('customerAddress').value=c.address||''; el('customerNotes').value=c.notes||'';
  setView('customers'); window.scrollTo({top:0,behavior:'smooth'});
}
function deleteCustomer(id) {
  if(!confirm('Delete this customer? Related devices/jobs will remain but customer name will show Unknown.')) return;
  HS.data.customers = HS.data.customers.filter(c=>c.id!==id); saveData();
}

function collectDevice() {
  return {
    id: el('deviceId').value || uid('dev'), customerId: el('deviceCustomer').value, category: el('deviceCategory').value, brand: el('deviceBrand').value.trim(), model: el('deviceModel').value.trim(),
    serial: el('deviceSerial').value.trim(), asset: el('deviceAsset').value.trim(), processor: el('deviceProcessor').value.trim(), ram: el('deviceRam').value.trim(), ssd: el('deviceSsd').value.trim(), hdd: el('deviceHdd').value.trim(), gpu: el('deviceGpu').value.trim(), windows: el('deviceWindows').value.trim(), accessories: el('deviceAccessories').value.trim(), createdAt: todayISO()
  };
}
function editDevice(id) {
  const d = HS.data.devices.find(x=>x.id===id); if(!d) return;
  el('deviceId').value=d.id; el('deviceCustomer').value=d.customerId; el('deviceCategory').value=d.category; el('deviceBrand').value=d.brand||''; el('deviceModel').value=d.model||''; el('deviceSerial').value=d.serial||''; el('deviceAsset').value=d.asset||''; el('deviceProcessor').value=d.processor||''; el('deviceRam').value=d.ram||''; el('deviceSsd').value=d.ssd||''; el('deviceHdd').value=d.hdd||''; el('deviceGpu').value=d.gpu||''; el('deviceWindows').value=d.windows||''; el('deviceAccessories').value=d.accessories||'';
  setView('devices'); window.scrollTo({top:0,behavior:'smooth'});
}
function deleteDevice(id) {
  if(!confirm('Delete this device? Related jobs will remain but device name will show Unknown.')) return;
  HS.data.devices = HS.data.devices.filter(d=>d.id!==id); saveData();
}

function collectJob() {
  const existing = HS.data.jobs.find(j=>j.id===el('jobId').value);
  return {
    id: el('jobId').value || uid('job'), jobNumber: existing?.jobNumber || generateJobNumber(), createdAt: existing?.createdAt || todayISO(),
    customerId: el('jobCustomer').value, deviceId: el('jobDevice').value, serviceType: el('jobServiceType').value, status: el('jobStatus').value,
    priority: el('jobPriority').value, technician: el('jobTechnician').value.trim(), problem: el('jobProblem').value.trim(), engineerNotes: el('jobEngineerNotes').value.trim(), estimate: Number(el('jobEstimate').value||0), paid: Number(el('jobPaid').value||0), warrantyDays: Number(el('jobWarrantyDays').value||0), deliveryDate: el('jobDeliveryDate').value, logs: existing?.logs || [], parts: existing?.parts || []
  };
}
function openJobForm() {
  if (!HS.data.customers.length) { alert('Please add a customer first.'); setView('customers'); return; }
  if (!HS.data.devices.length) { alert('Please add a device first.'); setView('devices'); return; }
  el('jobModalTitle').textContent = 'Create Service Job';
  el('jobForm').reset(); el('jobId').value=''; el('jobStatus').value='Received'; el('jobPriority').value='Medium'; el('jobEstimate').value=0; el('jobPaid').value=0; el('jobWarrantyDays').value=30;
  renderSelects(); el('jobModal').classList.remove('hidden');
}
function editJob(id) {
  const j = HS.data.jobs.find(x=>x.id===id); if(!j) return;
  el('jobModalTitle').textContent = `Edit ${j.jobNumber}`;
  el('jobId').value=j.id; el('jobCustomer').value=j.customerId; renderJobDeviceOptions(j.customerId); el('jobDevice').value=j.deviceId; el('jobServiceType').value=j.serviceType; el('jobStatus').value=j.status; el('jobPriority').value=j.priority; el('jobTechnician').value=j.technician||''; el('jobProblem').value=j.problem||''; el('jobEngineerNotes').value=j.engineerNotes||''; el('jobEstimate').value=j.estimate||0; el('jobPaid').value=j.paid||0; el('jobWarrantyDays').value=j.warrantyDays||0; el('jobDeliveryDate').value=j.deliveryDate||'';
  el('jobModal').classList.remove('hidden');
}
function deleteJob(id) {
  if(!confirm('Delete this service job?')) return;
  HS.data.jobs = HS.data.jobs.filter(j=>j.id!==id); saveData();
}

function openJobDetails(id) {
  const j = HS.data.jobs.find(x=>x.id===id); if(!j) return;
  const due = Math.max(0, Number(j.estimate||0)-Number(j.paid||0));
  el('detailsTitle').textContent = `${j.jobNumber} Details`;
  el('jobDetailsContent').innerHTML = `
    <div class="details-grid">
      <div class="detail-card"><span>Customer</span><strong>${esc(customerName(j.customerId))}</strong><small>${esc(customerMobile(j.customerId))}</small></div>
      <div class="detail-card"><span>Device</span><strong>${esc(deviceLabel(j.deviceId))}</strong></div>
      <div class="detail-card"><span>Status</span><strong><span class="badge ${esc(j.status.split(' ')[0])}">${esc(j.status)}</span></strong></div>
      <div class="detail-card"><span>Estimate</span><strong>${money(j.estimate)}</strong></div>
      <div class="detail-card"><span>Paid</span><strong>${money(j.paid)}</strong></div>
      <div class="detail-card"><span>Due</span><strong>${money(due)}</strong></div>
      <div class="detail-card"><span>Warranty End</span><strong>${formatDate(warrantyEnd(j))}</strong></div>
      <div class="detail-card"><span>Priority</span><strong>${esc(j.priority)}</strong></div>
      <div class="detail-card"><span>Technician</span><strong>${esc(j.technician || '-')}</strong></div>
    </div>
    <div class="panel no-print"><h3>Problem</h3><p>${esc(j.problem)}</p><h3>Engineer Notes</h3><p>${esc(j.engineerNotes || '-')}</p></div>
    <div class="grid-2 no-print">
      <div class="panel"><h3>Add Work Log</h3><div class="add-row"><input id="newLogTime" type="time"><input id="newLogText" placeholder="Work update"><button class="primary-btn" onclick="addLog('${j.id}')">Add</button></div><div class="timeline">${(j.logs||[]).map(l=>`<div class="timeline-item"><strong>${esc(l.time)}</strong><br>${esc(l.text)}</div>`).join('') || '<p class="empty">No work logs yet.</p>'}</div></div>
      <div class="panel"><h3>Add Parts Used</h3><div class="add-row"><input id="newPartName" placeholder="Part name"><input id="newPartPrice" type="number" min="0" placeholder="Sale price"><button class="primary-btn" onclick="addPart('${j.id}')">Add</button></div>${partsTable(j.parts||[])}</div>
    </div>
    <div class="panel no-print"><button class="primary-btn" onclick="printInvoice('${j.id}')">Print Invoice / Receipt</button> <button class="light-btn" onclick="editJob('${j.id}')">Edit Job</button></div>
    <div id="print_${j.id}" class="print-area">${invoiceHtml(j)}</div>
  `;
  el('detailsModal').classList.remove('hidden');
}

function partsTable(parts) {
  if (!parts.length) return '<p class="empty">No parts added.</p>';
  return `<table><thead><tr><th>Part</th><th>Qty</th><th>Sale</th></tr></thead><tbody>${parts.map(p=>`<tr><td>${esc(p.name)}</td><td>${p.qty || 1}</td><td>${money(p.salePrice)}</td></tr>`).join('')}</tbody></table>`;
}
function addLog(jobId) {
  const j = HS.data.jobs.find(x=>x.id===jobId); if(!j) return;
  const time = el('newLogTime').value || new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
  const text = el('newLogText').value.trim(); if(!text) return alert('Write work log text.');
  j.logs ||= []; j.logs.push({ time, text, date: todayISO() }); saveData(); openJobDetails(jobId);
}
function addPart(jobId) {
  const j = HS.data.jobs.find(x=>x.id===jobId); if(!j) return;
  const name = el('newPartName').value.trim(); const salePrice = Number(el('newPartPrice').value||0); if(!name) return alert('Write part name.');
  j.parts ||= []; j.parts.push({ id: uid('part'), name, qty: 1, salePrice });
  j.estimate = Number(j.estimate || 0) + salePrice;
  saveData(); openJobDetails(jobId);
}
function invoiceHtml(j) {
  const c = HS.data.customers.find(x=>x.id===j.customerId) || {};
  const d = HS.data.devices.find(x=>x.id===j.deviceId) || {};
  const due = Math.max(0, Number(j.estimate||0)-Number(j.paid||0));
  return `<div style="font-family:Arial,sans-serif;color:#111;">
    <h1 style="margin:0;">Habitable Solution</h1>
    <p style="margin:4px 0 20px;">Service Invoice / Money Receipt</p>
    <hr>
    <table style="width:100%;border-collapse:collapse;margin:15px 0;">
      <tr><td><strong>Job Number:</strong> ${esc(j.jobNumber)}</td><td><strong>Date:</strong> ${formatDate(j.createdAt)}</td></tr>
      <tr><td><strong>Customer:</strong> ${esc(c.name || '')}</td><td><strong>Mobile:</strong> ${esc(c.mobile || '')}</td></tr>
      <tr><td><strong>Device:</strong> ${esc(`${d.category || ''} ${d.brand || ''} ${d.model || ''}`)}</td><td><strong>Serial:</strong> ${esc(d.serial || '-')}</td></tr>
      <tr><td><strong>Service:</strong> ${esc(j.serviceType)}</td><td><strong>Status:</strong> ${esc(j.status)}</td></tr>
    </table>
    <h3>Problem</h3><p>${esc(j.problem)}</p>
    <h3>Parts Used</h3>${partsTable(j.parts || [])}
    <table style="width:100%;border-collapse:collapse;margin-top:20px;">
      <tr><td><strong>Estimate / Bill</strong></td><td style="text-align:right;">${money(j.estimate)}</td></tr>
      <tr><td><strong>Paid</strong></td><td style="text-align:right;">${money(j.paid)}</td></tr>
      <tr><td><strong>Due</strong></td><td style="text-align:right;">${money(due)}</td></tr>
      <tr><td><strong>Warranty Ends</strong></td><td style="text-align:right;">${formatDate(warrantyEnd(j))}</td></tr>
    </table>
    <div style="display:flex;justify-content:space-between;margin-top:70px;"><span>Customer Signature</span><span>Authorized Signature</span></div>
  </div>`;
}
function printInvoice(id) { window.print(); }

function removeSetting(type, value) {
  if(!confirm(`Remove ${value}?`)) return;
  HS.data.settings[type] = HS.data.settings[type].filter(x=>x!==value); saveData();
}

function exportBackup() {
  const blob = new Blob([JSON.stringify(HS.data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `hs-sms-backup-${todayISO()}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
}
function importBackup(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if (!data.customers || !data.devices || !data.jobs) throw new Error('Invalid backup file');
      HS.data = data; saveData(); alert('Backup imported successfully.');
    } catch(e) { alert('Invalid backup file.'); }
  };
  reader.readAsText(file);
}

function bindEvents() {
  el('todayText').textContent = new Date().toLocaleDateString('en-GB', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
  document.querySelectorAll('.nav-btn').forEach(btn => btn.addEventListener('click', () => setView(btn.dataset.view)));
  document.querySelectorAll('[data-open-job-form]').forEach(btn => btn.addEventListener('click', openJobForm));
  document.querySelectorAll('[data-close-modal]').forEach(btn => btn.addEventListener('click', () => el('jobModal').classList.add('hidden')));
  document.querySelectorAll('[data-close-details]').forEach(btn => btn.addEventListener('click', () => el('detailsModal').classList.add('hidden')));
  el('globalSearch').addEventListener('input', renderAll);
  el('clearSearch').addEventListener('click', () => { el('globalSearch').value=''; renderAll(); });
  el('jobCustomer').addEventListener('change', e => renderJobDeviceOptions(e.target.value));
  el('customerForm').addEventListener('submit', e => { e.preventDefault(); const c = collectCustomer(); const i = HS.data.customers.findIndex(x=>x.id===c.id); if(i>=0) HS.data.customers[i]=c; else HS.data.customers.push(c); e.target.reset(); el('customerId').value=''; saveData(); });
  el('deviceForm').addEventListener('submit', e => { e.preventDefault(); const d = collectDevice(); const i = HS.data.devices.findIndex(x=>x.id===d.id); if(i>=0) HS.data.devices[i]=d; else HS.data.devices.push(d); e.target.reset(); el('deviceId').value=''; saveData(); });
  el('jobForm').addEventListener('submit', e => { e.preventDefault(); const j = collectJob(); const i = HS.data.jobs.findIndex(x=>x.id===j.id); if(i>=0) HS.data.jobs[i]=j; else HS.data.jobs.push(j); el('jobModal').classList.add('hidden'); saveData(); setView('jobs'); });
  el('serviceTypeForm').addEventListener('submit', e => { e.preventDefault(); const v=el('newServiceType').value.trim(); if(v && !HS.data.settings.serviceTypes.includes(v)) HS.data.settings.serviceTypes.push(v); e.target.reset(); saveData(); });
  el('categoryForm').addEventListener('submit', e => { e.preventDefault(); const v=el('newCategory').value.trim(); if(v && !HS.data.settings.categories.includes(v)) HS.data.settings.categories.push(v); e.target.reset(); saveData(); });
  el('backupBtn').addEventListener('click', exportBackup);
  el('importFile').addEventListener('change', e => e.target.files[0] && importBackup(e.target.files[0]));
  el('resetBtn').addEventListener('click', () => { if(confirm('Are you sure? Export backup first.')) { localStorage.removeItem(HS.key); loadData(); saveData(); } });
}

loadData();
bindEvents();
renderAll();
window.openJobDetails = openJobDetails;
window.editJob = editJob;
window.deleteJob = deleteJob;
window.editCustomer = editCustomer;
window.deleteCustomer = deleteCustomer;
window.editDevice = editDevice;
window.deleteDevice = deleteDevice;
window.addLog = addLog;
window.addPart = addPart;
window.printInvoice = printInvoice;
window.removeSetting = removeSetting;
